public class Pelatihan2_Modul1 {
}
